Use template from `job1` to create this job 
