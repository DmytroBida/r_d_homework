"""
Tests sales_api.py module.
# TODO: write tests
"""
from unittest import TestCase, mock

# NB: avoid relative imports when you will write your code:
from lesson_02.ht_template.job1.dal.sales_api import get_sales


class GetSalesTestCase(TestCase):
    """
    Test sales_api.get_sales function.
    # TODO: implement
    """
    pass
