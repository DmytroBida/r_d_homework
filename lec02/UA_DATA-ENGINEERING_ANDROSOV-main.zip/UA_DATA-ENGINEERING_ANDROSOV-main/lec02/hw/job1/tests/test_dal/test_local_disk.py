"""
Tests dal.local_disk.py module
# TODO: write tests
"""
from unittest import TestCase, mock

from lesson_02.ht_template.job1.dal.local_disk import save_to_disk


class SaveToDiskTestCase(TestCase):
    """
    Test dal.local_disk.save_to_disk function.
    # TODO: implement
    """
    pass
