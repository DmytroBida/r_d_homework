from typing import List, Dict, Any


def save_to_disk(json_content: List[Dict[str, Any]], path: str) -> None:
    # TODO: implement me mfklsdmfkl
    pass
