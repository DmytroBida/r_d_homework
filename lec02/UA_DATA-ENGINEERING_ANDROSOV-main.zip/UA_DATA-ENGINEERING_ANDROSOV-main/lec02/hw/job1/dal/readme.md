# Data Access Layer

Put modules into this folder that contains code for access 
any data storage, persistent storage, database, message buffer etc.


Please, read for more details:
- https://en.wikipedia.org/wiki/Data_access_layer
- https://martinfowler.com/bliki/PresentationDomainDataLayering.html
