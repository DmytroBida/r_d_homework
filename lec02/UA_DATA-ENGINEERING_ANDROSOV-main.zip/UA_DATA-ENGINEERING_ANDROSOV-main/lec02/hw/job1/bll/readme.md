# Business Logic Layer

Contains code for data manipulation, transformation and any type
of business logic.

Please, read for more details:
- https://learn.microsoft.com/en-us/aspnet/web-forms/overview/data-access/introduction/creating-a-business-logic-layer-cs
- https://en.wikipedia.org/wiki/Business_logic
